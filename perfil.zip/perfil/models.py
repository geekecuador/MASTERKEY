from django.db import models
from contrato.models import Estudiante,Nivel

# Create your models here.

class Perfil(models.Model):
   
    usuario = models.ForeignKey(Estudiante)
    nivel = models.ForeignKey(Nivel)
    def __unicode__(self):
        return "%s -  %s" % (self.usuario,self.nivel)